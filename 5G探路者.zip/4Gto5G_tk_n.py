# -*- coding: utf-8 -*-
"""
Created on Mon May 27 16:13:17 2019

@author: huangyijun
"""
import os
import pandas as pd
import time
import math
import Tkinter as tk
import tkFileDialog
import threading
import base64
from icon import img
root=os.getcwd()

tmp = open(root + '\\bitbug_favicon.ico','wb+')
tmp.write(base64.b64decode(img))
tmp.close()

window = tk.Tk()
window.title(u'5G探路者')
window.iconbitmap(root + '\\bitbug_favicon.ico')
os.remove(root + '\\bitbug_favicon.ico')
window.geometry('400x305')


def open_file_1():
    default_dir = r"C:\Users\lenovo\Desktop"  # 设置默认打开目录
    fname1 = tkFileDialog.askopenfilename(title=u"选择文件",
                                         initialdir=(os.path.expanduser(default_dir)))
    t1.delete(0.0,tk.END)
    t1.insert('insert',fname1)
    return fname1

def open_file_2():
    default_dir = r"C:\Users\lenovo\Desktop"  # 设置默认打开目录
    fname2 = tkFileDialog.askopenfilename(title=u"选择文件",
                                         initialdir=(os.path.expanduser(default_dir)))
    t2.delete(0.0,tk.END)
    t2.insert('insert',fname2)
    return fname2

def open_file_3():
    #default_dir = r"C:\Users\lenovo\Desktop"  # 设置默认打开目录
    #fname2 = 
    fname3 = tkFileDialog.askopenfilenames(filetypes=[('excel files', '.xls')])

    t3.delete(0.0,tk.END)
    t3.insert('insert',fname3)
    return fname3

def open_file_4():
    #default_dir = r"C:\Users\lenovo\Desktop"  # 设置默认打开目录
    #fname2 = 
    fname4 = tkFileDialog.askopenfilenames(filetypes=[('excel files', '.xls')])

    t4.delete(0.0,tk.END)
    t4.insert('insert',fname4)
    return fname4

b1 = tk.Button(window,
              text=u'导入工参文件',
              width=15,height=2,
              command=open_file_1)
b1.grid(row=1,column=0)

t1 = tk.Text(window,height=2,width=39)
t1.grid(row=1,column=1,sticky='e',columnspan=4)

b2 = tk.Button(window,
              text=u'导入扫频文件',
              width=15,height=2,
              command=open_file_2)
b2.grid(row=2,column=0)

t2 = tk.Text(window,height=2,width=39)
t2.grid(row=2,column=1,sticky='e',columnspan=4)

b3 = tk.Button(window,
              text=u'打开4G天线文件',
              width=15,height=2,
              command=open_file_3)
b3.grid(row=3,column=0)
t3 = tk.Text(window,height=2,width=39)
t3.grid(row=3,column=1,sticky='e',columnspan=4)

b4 = tk.Button(window,
              text=u'打开5G天线文件',
              width=15,height=2,
              command=open_file_4)
b4.grid(row=4,column=0)
t4 = tk.Text(window,height=2,width=39)
t4.grid(row=4,column=1,sticky='e',columnspan=4)



def Haversin(i):
    v = math.sin(i/2)
    return v*v

def caldistance(Aj,Aw,Bj,Bw):    
    EarthRadius = 6371004
#角度转换弧度
    latA = math.radians(Aw)
    lonA = math.radians(Aj)
    latB = math.radians(Bw)
    lonB = math.radians(Bj)
#计算距离
    vlat = math.fabs(latA-latB)
    vlon = math.fabs(lonA-lonB)

    h = Haversin(vlat) + math.cos(latA) * math.cos(latB) * Haversin(vlon)
    d = 2 * EarthRadius * math.asin(math.sqrt(h))
    distance = round(d,1)
    return distance
    #print("距离:%.1f米" % distance)

def calfwj(Aj,Aw,Bj,Bw):
    #角度转换弧度
    latA = math.radians(Aw)
    lonA = math.radians(Aj)
    latB = math.radians(Bw)
    lonB = math.radians(Bj)
    #print Aj,Bj
    azimuth = math.sin(latA)*math.sin(latB)+math.cos(latA)*math.cos(latB)*math.cos(lonB-lonA)
    azimuth = math.sqrt(1-azimuth*azimuth)
    azimuth = math.cos(latB)*math.sin(lonB-lonA)/azimuth
    #print j,Aw,Aj,Bw,Bj,azimuth
    if azimuth < -1 :
        azimuth = -1
    elif azimuth > 1 :
        azimuth = 1
    azimuth = math.degrees(math.asin(azimuth))
    if Bw<=Aw:
        fwj = 180 - azimuth
    elif Bw>Aw and Bj>=Aj:
        fwj = azimuth
    elif Bw>Aw and Bj<Aj:
        fwj = 360 + azimuth
    #else:
    #    fwj = 0
    fwj = round(fwj,4)
    return fwj

def caltilt(distance,height):
    H = height
    tilt = math.atan(distance/H)
    tilt = math.degrees(tilt)
    return tilt

def changeangle(data):
    if data >=0:
        data = math.floor(data)
    else:
        data = math.ceil(data)
        if data !=0:
            data = 360+data
    return data

def searchHash(hashid,dataid): #在哈希表中查找数据，返回地址
    hashAddress=hash(dataid)
    while hashid.get(hashAddress) and hashid[hashAddress]!=dataid: #数据冲突时开放寻址
        hashAddress+=1
        hashAddress=hash(hashAddress)
    if hashid.get(hashAddress)==None:
        return None
    return hashAddress

def insertHash(hashid,hashlon,hashlat,hasht,hasho,hashh,hashp,hash4t,hash5t,dataid,datalon,datalat,datat,datao,datah,datap,data4t,data5t): #建立cellid和索引两个哈希表
    hashAddress=hash(dataid)
    #如果key存在说明应经被别人占用， 需要解决冲突
    while(hashid.get(hashAddress)):
        #用开放寻执法
        hashAddress+=1
        hashAddress=hash(hashAddress)
    hashid[hashAddress]=dataid
    hashlon[hashAddress]=datalon
    hashlat[hashAddress]=datalat
    hasht[hashAddress]=datat
    hasho[hashAddress]=datao
    hashh[hashAddress]=datah
    hashp[hashAddress]=datap
    hash4t[hashAddress]=data4t
    hash5t[hashAddress]=data5t

def frames4G(xlsstr):
    xlsnames = xlsstr.split(" ")
    keyword = "xls"
    datalist = []
    for data in xlsnames:
        #print xlsnames
        if data.find(keyword)!=-1:
            datalist.append(data)
    #print datalist
    filename4G = []
    for i in range (len(datalist)):
        filename4G.append(datalist[i][datalist[i].find('4G_'):-4])
    framesho4G = []
    framesvo4G = []
    for i in range(len(datalist)):
        hosheetname = filename4G[i] + '_H'
        vosheetname = filename4G[i] + '_V'
        df_ho_4G_temp = pd.DataFrame(pd.read_excel(datalist[i],header=0, dtype={'PCI':str, 'FQP': str,'TILT':str,'ORT':str},sheet_name=hosheetname)) 
        df_vo_4G_temp = pd.DataFrame(pd.read_excel(datalist[i],header=0, sheet_name=vosheetname))  
        framesho4G.append(df_ho_4G_temp)
        framesvo4G.append(df_vo_4G_temp)  
    return framesho4G,framesvo4G,filename4G

def frames5G(xlsstr):
    xlsnames = xlsstr.split(" ")
    keyword = "xls"
    datalist = []
    for data in xlsnames:
        #print xlsnames
        if data.find(keyword)!=-1:
            datalist.append(data)
    #print datalist
    filename5G = []
    for i in range (len(datalist)):
        filename5G.append(datalist[i][datalist[i].find('5G_'):-4]) 
    framesho5G = []
    framesvo5G = []
    for i in range(len(datalist)):
        hosheetname = filename5G[i] + '_H'
        vosheetname = filename5G[i] + '_V'
        df_ho_5G_temp = pd.DataFrame(pd.read_excel(datalist[i],header=0, dtype={'PCI':str, 'FQP': str,'TILT':str,'ORT':str},sheet_name=hosheetname)) 
        df_vo_5G_temp = pd.DataFrame(pd.read_excel(datalist[i],header=0, sheet_name=vosheetname))  
        framesho5G.append(df_ho_5G_temp)
        framesvo5G.append(df_vo_5G_temp)  
    return framesho5G,framesvo5G,filename5G

def mainEXE():
    l2['text']=''
    insstart = time.time()
    #paramefn = r'D:\HYJ\4Gto5G\gc1105(2).CSV'
    paramefn = str(t1.get(0.0,tk.END).encode('utf-8')).strip('\n').decode('utf-8')
    #testlogfn = 'D:\HYJ\\4Gto5G\AnalysisResultCMCC4.csv'
    #testlogfn = r'D:\HYJ\4Gto5G\4G19.csv'
    testlogfn = str(t2.get(0.0,tk.END).encode('utf-8')).strip('\n').decode('utf-8')
    print paramefn
    print testlogfn
    #offsetfn4G = r'D:\HYJ\4Gto5G\4G_HV.xls'
    #offsetfn5G = r'D:\HYJ\4Gto5G\5G_HV.xls'
    #lognet = '19'
    #lognet = str(e1.get().encode('utf-8')).decode('utf-8') 
    lognet = testlogfn[-6:-4]
    framesho4G = []
    framesvo4G = []
    framesho5G = []
    framesvo5G = []
    #xlsstr4G= 'D:/HYJ/4Gto5G/SSBfile/4G_jingxin.xls D:/HYJ/4Gto5G/SSBfile/4G_tongyu.xls'
    #xlsstr5G= 'D:/HYJ/4Gto5G/SSBfile/5G_1SSB.xls D:/HYJ/4Gto5G/SSBfile/5G_2SSB.xls D:/HYJ/4Gto5G/SSBfile/5G_4SSB.xls D:/HYJ/4Gto5G/SSBfile/5G_8SSB.xls'
    xlsstr4G = str(t3.get(0.0,tk.END).encode('utf-8')).strip('\n').decode('utf-8')
    #print xlsstr4G
    xlsstr5G = str(t4.get(0.0,tk.END).encode('utf-8')).strip('\n').decode('utf-8')
    framesho4G,framesvo4G,xlsnames4G=frames4G(xlsstr4G)
    framesho5G,framesvo5G,xlsnames5G=frames5G(xlsstr5G)
    df_ho_4G_all = pd.concat(framesho4G,keys=xlsnames4G)
    df_ho_5G_all = pd.concat(framesho5G,keys=xlsnames5G)
    df_vo_4G_all = pd.concat(framesvo4G,keys=xlsnames4G)
    df_vo_5G_all = pd.concat(framesvo5G,keys=xlsnames5G)
    #print df_ho_5G_all
    
    
           
    df_pm = pd.DataFrame(pd.read_csv(paramefn, usecols = [8,10,17,18,25,26,27,28,47,48],names=['PCI','FQP','LON','LAT','TILT','ORT','HGH','POW','4Gatn','5Gatn'], header=0,low_memory=False, dtype={'PCI':str, 'FQP': str,'TILT':str,'ORT':str})) 
    #print df_pm
    df_tl = pd.DataFrame(pd.read_csv(testlogfn, usecols = [0,1,2,3,4,7], header=0,low_memory=False)) 
    #df_ho_4G = pd.DataFrame(pd.read_csv(hoffsetfn4G, header=0,low_memory=False, dtype={'PCI':str, 'FQP': str,'TILT':str,'ORT':str})) 
    #df_vo_4G = pd.DataFrame(pd.read_csv(voffsetfn4G, header=0,low_memory=False)) 
    #df_ho_4G = pd.DataFrame(pd.read_excel(offsetfn4G,header=0, dtype={'PCI':str, 'FQP': str,'TILT':str,'ORT':str},sheet_name='4G_HO'))  
    #df_vo_4G = pd.DataFrame(pd.read_excel(offsetfn4G,header=0, sheet_name='4G_VO'))  
    #df_ho_5G = pd.DataFrame(pd.read_csv(hoffsetfn5G, header=0,low_memory=False, dtype={'PCI':str, 'FQP': str,'TILT':str,'ORT':str})) 
    #df_vo_5G = pd.DataFrame(pd.read_csv(voffsetfn5G, header=0,low_memory=False)) 
    #df_ho_5G = pd.DataFrame(pd.read_excel(offsetfn5G,header=0, dtype={'PCI':str, 'FQP': str,'TILT':str,'ORT':str},sheet_name='5G_HO'))  
    #df_vo_5G = pd.DataFrame(pd.read_excel(offsetfn5G,header=0, sheet_name='5G_VO'))  
    
    df_final = pd.DataFrame(pd.read_csv(testlogfn, header=0,low_memory=False))
    df_finalnopow = pd.DataFrame(pd.read_csv(testlogfn, header=0,low_memory=False))
    
    df_tl['NEWRSRP']=None
    df_tl['4GHOffset']=None
    df_tl['4GVOffset']=None
    df_tl['5GHOffset']=None
    df_tl['5GVOffset']=None
    df_tl['PowerOffset']=None
    df_final['distance']=None
    df_finalnopow['distance']=None
    MaxHO4G_angle = 359
    MaxVO4G_angle = 359
    MaxHO5G_angle = 351
    MaxVO5G_angle = 6
    
    list1 = df_pm.columns.values.tolist() 
    list2 = df_tl.columns.values.tolist() 
    df_m = pd.DataFrame(columns = list(list1))
    df_t = pd.DataFrame(columns = list(list2))
    df_m = df_pm
    df_t = df_tl
    df_m[df_m.columns[0]]=df_pm[df_pm.columns[0]].astype(str)+df_pm[df_pm.columns[1]].astype(str)
    df_t[df_t.columns[3]]=df_tl[df_tl.columns[4]].astype(str)+df_tl[df_tl.columns[3]].astype(str)
    
    #print df_t.iloc[:,5]
    
    
    #   根据cellid匹配CSV文件，进行哈希查找    
    ll = len(df_pm)
    #    print ll
    Arrid = []
    Arrlon = []
    Arrlat = []
    Arrt = []
    Arro = []
    Arrh = []
    Arrp = []
    Arr4t = []
    Arr5t = []
    hashid={}  #用于记录cellid
    hashlon={}  #用于记录该记录在原始表格中第几行
    hashlat={}  #用于记录cellid
    hasht={}  #用于记录该记录在原始表格中第几行
    hasho={}  #用于记录
    hashh={}
    hashp={}
    hash4t={}
    hash5t={}
    
    Arrid=df_pm.iloc[:,0].values
    Arrlon=df_pm.iloc[:,2].values
    Arrlat=df_pm.iloc[:,3].values
    Arrt=df_pm.iloc[:,4].values
    Arro=df_pm.iloc[:,5].values
    Arrh=df_pm.iloc[:,6].values
    Arrp=df_pm.iloc[:,7].values
    Arr4t=df_pm.iloc[:,8].values
    Arr5t=df_pm.iloc[:,9].values
    
    
    for i in range(0,ll): #建立哈希表
        insertHash(hashid,hashlon,hashlat,hasht,hasho,hashh,hashp,hash4t,hash5t,Arrid[i],Arrlon[i],Arrlat[i],Arrt[i],Arro[i],Arrh[i],Arrp[i],Arr4t[i],Arr5t[i])
    insend = time.time()
    print insend-insstart
    
    
    schstart = time.time()
    lt = len(df_t)
    cellidlist = []
    ii = 0
    jj = 0
    il = 0
    count = 0
    
    #print df_t
    
    for j in range(0,lt):
        l1['text']=u'已完成：%.2f' % ((float(j)/float(lt))*100) + '%'
        if j==lt-1:
            l1['text']=u'已完成：100%'
            l2['text']=u'文件已经保存至final%s.csv\n和finalnopow%s.csv文件中' % (lognet, lognet)
        rsrp = df_t.iloc[j,5]
        cellid= df_t.iloc[j,3]
        #print il,rsrpmaxloc,cellid
        #print 'xxx'
        #print cellid
        #print 'yyy'
        result = searchHash(hashid,cellid)
        hashlonall = []
        hashlatall = []
        hashtall = []
        hashoall = []
        hashhall = []
        hashpall = []
        hash4tall = []
        hash5tall = []
        distancelist = []
        while hashid.get(result) and hashid[result]==cellid:
            hashlonall.append(hashlon[result])
            hashlatall.append(hashlat[result])
            hashtall.append(hasht[result])
            hashoall.append(str(hasho[result]))
            hashhall.append(hashh[result])
            hashpall.append(hashp[result])
            hash4tall.append(hash4t[result])
            hash5tall.append(hash5t[result])
            result+=1
            result = hash(result)
        length = len(hashlonall)
        for i in range(0,length):
            Aj=hashlonall[i]
            Aw=hashlatall[i]
            Bj = df_t.iloc[j,1]
            Bw = df_t.iloc[j,2]
            distance=caldistance(Aj,Aw,Bj,Bw)
            distancelist.append(distance)
            #if cellid == '35237900':
                #print cellid
                #print Aj,Aw,Bj,Bw
        #if cellid == '35237900':
            #print distancelist
        mindis = min(distancelist)
        loc = distancelist.index(mindis)
            #print mindis
                
        #print str(hashtall[loc])
        if hashoall[loc] =='nan' or hashoall[loc]=='nan' or hashhall[loc]=='nan' or str(hashtall[loc])=='nan':
            #print 'No.%s cellid:%s lon:%s lat:%s Data missing, cannot transfer' % ( jj, cellid, hashlonall[loc],hashlatall[loc]) 
            df_tl.iloc[j,6] = df_tl.iloc[j,5]
            rsrpmaxnopow = df_final.iloc[j,7]
            if rsrpmaxnopow >-50:
                df_final.iloc[j,12]='1'
                df_finalnopow.iloc[j,12]='1'
            elif rsrpmaxnopow <-50 and rsrpmaxnopow>-55:
                df_final.iloc[j,12]='2'
                df_finalnopow.iloc[j,12]='2'
            elif rsrpmaxnopow <-55 and rsrpmaxnopow>-60:
                df_final.iloc[j,12]='3'
                df_finalnopow.iloc[j,12]='3' 
            elif rsrpmaxnopow <-60 and rsrpmaxnopow>-65:
                df_final.iloc[j,12]='4'
                df_finalnopow.iloc[j,12]='4'
            elif rsrpmaxnopow <-65 and rsrpmaxnopow>-70:
                df_final.iloc[j,12]='5'
                df_finalnopow.iloc[j,12]='5'
            elif rsrpmaxnopow <-70 and rsrpmaxnopow>-75:
                df_final.iloc[j,12]='6'
                df_finalnopow.iloc[j,12]='6'
            elif rsrpmaxnopow <-75 and rsrpmaxnopow>-80:
                df_final.iloc[j,12]='7'
                df_finalnopow.iloc[j,12]='7'
            elif rsrpmaxnopow <-80 and rsrpmaxnopow>-85:
                df_final.iloc[j,12]='8'
                df_finalnopow.iloc[j,12]='8'
            else:
                df_final.iloc[j,12]='9'
                df_finalnopow.iloc[j,12]='9'
            df_final.iloc[j,11]='Incomplete_Parameter'
            df_finalnopow.iloc[j,11]='Incomplete_Parameter'
    
        else:
            Aj=hashlonall[loc]
            Aw=hashlatall[loc]
            if Aj and Aw and Bj and Bw:
                fwj = calfwj(Aj,Aw,Bj,Bw)
                deltafwj = fwj - float(hashoall[loc])
                deltafwj = int(changeangle(deltafwj))
                tilt = caltilt(mindis,hashhall[loc])
                
                #print 'No.%s cellid:%s rsrp:%.2f lon:%s lat:%s tilt:%s ort:%s height:%s deltafwj:%s deltatilt:%s' % ( jj, cellid,rsrpmax ,hashlonall[loc],hashlatall[loc],hashtall[loc],hashoall[loc],hashhall[loc],deltafwj,tilt) 
                #print tilt,Aj,Aw,hashtall[loc]
                deltilt = math.floor((90-tilt)-float(hashtall[loc])) #向下取整
                #if deltilt>0:      
                #    print mindis,hashhall[loc],tilt,hashtall[loc],deltilt
                #print deltilt
                deltilt = int(changeangle(deltilt))
                #print deltilt
                #print hash4tall[loc],hash5tall[loc]
                df_ho_4G = df_ho_4G_all.loc[(hash4tall[loc],slice(None)),:].reset_index(drop=True)
                df_vo_4G = df_vo_4G_all.loc[(hash4tall[loc],slice(None)),:].reset_index(drop=True)
                df_ho_5G = df_ho_5G_all.loc[(hash5tall[loc],slice(None)),:].reset_index(drop=True)
                df_vo_5G = df_vo_5G_all.loc[(hash5tall[loc],slice(None)),:].reset_index(drop=True)
                #print df_ho_4G
                if str(hashpall[loc])=='nan':
                    HO4G = df_ho_4G.iloc[deltafwj,1]
                    VO4G = df_vo_4G.iloc[MaxVO4G_angle,1]-df_vo_4G.iloc[(MaxVO4G_angle+deltilt)%360,1]
                    HO5G = df_ho_5G.iloc[deltafwj,1]
                    VO5G = df_vo_5G.iloc[MaxVO5G_angle,1]-df_vo_5G.iloc[(MaxVO5G_angle+deltilt)%360,1]
                    rsrpmaxpow = rsrp + (HO5G - VO5G) - (HO4G - VO4G) + 2.8
                    rsrpmaxnopow = rsrp + (HO5G - VO5G) - (HO4G - VO4G)
                    #rsrpmaxnopow = rsrpmax + round(random.uniform(-3,8),1)
                    df_tl.iloc[j,9]=2.8
                else:
                    HO4G = df_ho_4G.iloc[deltafwj,1]
                    VO4G = df_vo_4G.iloc[MaxVO4G_angle,1]-df_vo_4G.iloc[(MaxVO4G_angle+deltilt)%360,1]
                    HO5G = df_ho_5G.iloc[deltafwj,1]
                    VO5G = df_vo_5G.iloc[MaxVO5G_angle,1]-df_vo_5G.iloc[(MaxVO5G_angle+deltilt)%360,1]
                    rsrpmaxpow = rsrp + (HO5G - VO5G) - (HO4G - VO4G)+(156.0-float(hashpall[loc]))/10
                    rsrpmaxnopow = rsrp + (HO5G - VO5G) - (HO4G - VO4G)
                    #rsrpmaxnopow = rsrpmax + round(random.uniform(-3,8),1)
                    df_tl.iloc[j,11]=(156.0-float(hashpall[loc]))/10
                
                df_tl.iloc[j,6]=rsrpmaxpow
                df_tl.iloc[j,7]=df_ho_4G.iloc[deltafwj,1]
                df_tl.iloc[j,8]=df_vo_4G.iloc[MaxVO4G_angle,1]-df_vo_4G.iloc[(MaxVO4G_angle+deltilt)%360,1]
                df_tl.iloc[j,9]=df_ho_5G.iloc[deltafwj,1]
                df_tl.iloc[j,10]=df_vo_5G.iloc[MaxVO5G_angle,1]-df_vo_5G.iloc[(MaxVO5G_angle+deltilt)%360,1]
                df_final.iloc[j,7]=rsrpmaxpow
                df_finalnopow.iloc[j,7]=rsrpmaxnopow
                df_final.iloc[j,11]='5G_Estimated'
                df_finalnopow.iloc[j,11]='5G_Estimated'
                df_final.iloc[j,13]=deltafwj
                df_finalnopow.iloc[j,13]=deltafwj
                df_final.iloc[j,14]=deltilt
                df_finalnopow.iloc[j,14]=deltilt
                df_final.iloc[j,15]=mindis
                df_finalnopow.iloc[j,15]=mindis
                '''
                df_tl.iloc[j,6]=rsrpmaxpow
                df_tl.iloc[j,7]=df_ho.iloc[deltafwj,1]
                df_tl.iloc[j,8]=df_vo.iloc[deltilt,1]
                df_final.iloc[j,7]=rsrpmaxpow
                df_finalnopow.iloc[j,7]=rsrpmaxnopow
                df_final.iloc[j,11]='5G_Estimated'
                df_finalnopow.iloc[j,11]='5G_Estimated'
                df_final.iloc[j,13]=deltafwj
                df_finalnopow.iloc[j,13]=deltafwj
                df_final.iloc[j,14]=deltilt
                df_finalnopow.iloc[j,14]=deltilt
                df_final.iloc[j,15]=mindis
                df_finalnopow.iloc[j,15]=mindis
                '''
                if rsrpmaxnopow >-50:
                    df_final.iloc[j,12]='1'
                    df_finalnopow.iloc[j,12]='1'
                elif rsrpmaxnopow <-50 and rsrpmaxnopow>-55:
                    df_final.iloc[j,12]='2'
                    df_finalnopow.iloc[j,12]='2'
                elif rsrpmaxnopow <-55 and rsrpmaxnopow>-60:
                    df_final.iloc[j,12]='3'
                    df_finalnopow.iloc[j,12]='3' 
                elif rsrpmaxnopow <-60 and rsrpmaxnopow>-65:
                    df_final.iloc[j,12]='4'
                    df_finalnopow.iloc[j,12]='4'
                elif rsrpmaxnopow <-65 and rsrpmaxnopow>-70:
                    df_final.iloc[j,12]='5'
                    df_finalnopow.iloc[j,12]='5'
                elif rsrpmaxnopow <-70 and rsrpmaxnopow>-75:
                    df_final.iloc[j,12]='6'
                    df_finalnopow.iloc[j,12]='6'
                elif rsrpmaxnopow <-75 and rsrpmaxnopow>-80:
                    df_final.iloc[j,12]='7'
                    df_finalnopow.iloc[j,12]='7'
                elif rsrpmaxnopow <-80 and rsrpmaxnopow>-85:
                    df_final.iloc[j,12]='8'
                    df_finalnopow.iloc[j,12]='8'
                else:
                    df_final.iloc[j,12]='9'
                    df_finalnopow.iloc[j,12]='9'
    
                
        count+=1
        #print deltafwj
        jj=ii+1
        #print jj,lt
        if jj >= lt-1:
            break
    
    df_tl.to_csv('result%s.csv' % (lognet))
    df_final.to_csv('final%s.csv' % (lognet))
    df_finalnopow.to_csv('finalnopow%s.csv' % (lognet),index=False)
    schend = time.time()
    print schend-schstart

def fun():
    for i in range(1, 2):
        th=threading.Thread(target=mainEXE,args=())
        th.setDaemon(True)#守护线程
        th.start()

#w1 = tk.Label(window, text=u"网格号")
#w1.grid(row=5,column=0)
#e1 = tk.Entry(window,width=5,show=None)
#e1.grid(row=5, column=1, sticky='w')
        
b5 = tk.Button(window,text=u'执行',width=15,
            height=2,command=fun)
b5.grid(row=5,column=0)
l1=tk.Label(window)
l1.grid(row=5, column=1,columnspan=4)
l2=tk.Label(window)
l2.grid(row=6, column=1,columnspan=4)

window.mainloop()
